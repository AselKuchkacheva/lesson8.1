package kg.geektech.les8.game;

public class Main {

    public static void main(String[] args) {
        RPG_Game.startGame();
    }

}
