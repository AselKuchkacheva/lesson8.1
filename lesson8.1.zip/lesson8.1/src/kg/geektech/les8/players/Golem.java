package kg.geektech.les8.players;

public class Golem extends Hero {

    public Golem(int health, int damage) {
        super(health, damage, SuperAbility.SAVE_DAMAGE_AND_REVERT);

    }

    @Override
    public void applySuperAbility(Boss boss, Hero[] heroes) {

         //   int partOfBossDamage = this.getDamage()+(boss.getDamage()/5);
         //   this.setDamage(partOfBossDamage);

       // System.out.println("Golems damage = " + this.getDamage());


           // this.setDamage(this.getDamage()+(boss.getDamage()/5));
       // for (int i = 0; i < heroes.length; i++) {
         //   boss = boss.getHealth() - (heroes[i].setHealth(boss.getDamage()+(boss.getDamage()/5)));

       // }

    }
}
