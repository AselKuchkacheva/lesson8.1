package kg.geektech.les8.players;

public interface HavingSuperAbility {
    void applySuperAbility(Boss boss, Hero[] heroes);

}
