package kg.geektech.les8.players;

public enum SuperAbility {
    CRITICAL_DAMAGE, BOOST, HEAL, SAVE_DAMAGE_AND_REVERT
}
